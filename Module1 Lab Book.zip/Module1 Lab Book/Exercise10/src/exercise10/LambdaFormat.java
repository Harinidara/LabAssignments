package exercise10;
interface StringOperations
{
	String operation(String s);
}
public class LambdaFormat {
	public static void main(String[] args) {
		// final String str2;
		StringOperations space= (String str)->{
			  String str2 = "";
		for(int i=0;i<str.length();i++) 
		{
			         char c= str.charAt(i);    
			           str2=str2+c;
			           str2=str2+'\t';
		}
		return str2;
		};
		System.out.println(space.operation("CG"));	
	}

}

