package exercise10;

import java.math.*;
interface MathOperations{
	double operation(int x,int y);
}
public class LambaDemo {
public static void main(String[] args) {
	MathOperations power=(int x,int y)->Math.pow(x,y);
	System.out.println(power.operation(5, 2));
}
}

