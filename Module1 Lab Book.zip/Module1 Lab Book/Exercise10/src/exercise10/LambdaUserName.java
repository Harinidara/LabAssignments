package exercise10;
interface Authentication
{
	boolean operation(String username,String password);
}
public class LambdaUserName {
	public static void main(String[] args) {
		Authentication a=(String username,String password)->{
			if(username==password)
			return true;
			else 
				return false;
		};
		System.out.println(a.operation("abc", "abc"));
		}
	}


