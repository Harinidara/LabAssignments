package capgemini.com;

import java.util.Scanner;

public class IncreasingNumber {
  void checkNumber()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int num=sc.nextInt();
		boolean flag=false;
		int currentDigit = num % 10;
	       num = num/10;
	       while(num>0)
	       {
	           if(currentDigit <= num % 10)
	           {
	               flag = true;
	               break;
	           }
	           currentDigit = num % 10;
	           num = num/10;
	       }
	       if(flag)
	           System.out.println("Digits are not in increasing order.");
	       
	       else
	           System.out.println("Digits are in increasing order.");
	       
	    }
	
public static void main(String args[])
{
     IncreasingNumber inc=new IncreasingNumber();
     inc.checkNumber();
}
}

		
		
		
	


