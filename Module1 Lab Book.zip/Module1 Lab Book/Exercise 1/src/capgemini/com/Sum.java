package capgemini.com;

import java.util.Scanner;

public class Sum
{
		void calculateSum()
		{
		Scanner sc=new Scanner(System.in);
		int sum=0;
	    System.out.println("Enter n");
	    int n=sc.nextInt();
	   for(int i=0;i<=100;i++)
		   if((i%3==0)||(i%5==0))
			   sum=sum+i;
	          System.out.println(sum);   
	   
	}
public static void main(String args[])
{
	Sum s=new Sum();
	s.calculateSum();
}
}

