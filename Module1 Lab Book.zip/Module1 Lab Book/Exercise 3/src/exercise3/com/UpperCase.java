package exercise3.com;

import java.util.Scanner;

public class UpperCase {
public static void main(String[] args)
	{
	int n;
	        String temp;
	        Scanner s = new Scanner(System.in);
	        System.out.print("Enter number of names you want to enter:");
	        n = s.nextInt();
	        String a[] = new String[n];
	        Scanner s1 = new Scanner(System.in);
	        System.out.println("Enter all the names:");
	        for(int i=0;i<n;i++)
	        {
	            a[i]=s1.nextLine();
	        }
	        for (int i=0;i<n;i++)
	        {
	            for (int j=i+1;j<n;j++)
	            {
	                if (a[i].compareTo(a[j])>0)
	                {
	                    temp=a[i];
	                    a[i]=a[j];
	                    a[j]=temp;
	                }
	            }
	        }
	        System.out.print("Names in Sorted Order:");
	        for (int i=0;i<n-1;i++)
	        {
	            System.out.print(a[i]+",");
	        }
	        System.out.print(a[n-1]);
	        System.out.println("\n");
	        System.out.println("Strings in Upper Case and lower Case");
	        if(n%2==0)
	        {
	     for(int i=0;i<n/2;i++)
	     {
	    System.out.println(a[i].toUpperCase());
	     }
	     for(int i=n/2;i<n;i++)
	     {
	    System.out.println(a[i].toLowerCase());
	     }
	     
	     }
	        else
	        {
	        for(int i=0;i<n/2+1;i++)
	     {
	    System.out.println(a[i].toUpperCase());
	     }
	     for(int i=n/2+1;i<n;i++)
	     {
	    System.out.println(a[i].toLowerCase());
	     }
	       
	        }
	       
	       
	    }
	}



