package exercise7;
import java.util.*;

public class ReverseNumber {
	public int getSorted(int a[])
	{   
		String b1=Arrays.toString(a);
	    StringBuffer sb=new StringBuffer(b1);
		sb=sb.reverse();
		String s1=sb.toString();
		String s2[]=s1.replaceAll("\\[","").replaceAll("\\]","").split(" ,");
		ArrayList<Integer> a1=new ArrayList<Integer>();
		for(int i=0;i<s2.length;i++)
		{
			a1.add(Integer.parseInt(s2[i]));
		}
		Collections.sort(a1);
		String s3=a1.toString();
		String s4=s3.substring(1,s3.length()-1);
		String s5=s4.replace(", ","");
		int b=Integer.parseInt(s5);
		return b;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	      System.out.println("enter size");
	      int n=sc.nextInt();
	      System.out.println("Enter array elements");
	      int a[]=new int[n];
	      for(int i=0;i<n;i++)
	      {
	    	  a[i]=sc.nextInt();
	      }
	      ReverseNumber c=new ReverseNumber();
          System.out.println(c.getSorted(a));
    
	}
	
}
	



