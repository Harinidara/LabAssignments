package exercise7;
import java.io.*;
import java.util.*;

public class HashMapEx {
	public List getValues(HashMap<Integer,Object> hash)
	{
		 List<Integer> h= new ArrayList(hash.values());
		 TreeSet ts=new TreeSet();
		 ts.addAll(h);
		 List l1=new ArrayList();
		 l1.addAll(ts);
		 //Map<> sort=new TreeMap(h);
		// List <Integer> listobj=new ArrayList(sort.values());
		 //HashMap sort1=new HashMap(sort);
		  //Set set=sort.entrySet();
		  /*Iterator itr=set.iterator();
		  while(itr.hasNext())
		  {
			  Map.Entry m=(Map.Entry)itr.next();
			  System.out.println(m.getKey()+" "+m.getValue());
		  }*/
		  return l1;
	}
	
	
	public static void main(String[] args) {
	
		  HashMap<Integer,Object> hash=new HashMap();
		  List<Integer> hin= new ArrayList();
		  hash.put(2,120);
		  hash.put(1,10);
		  hash.put(3,20);
		  hash.put(4,2);
		  
		  /*Map sort=new TreeMap(hash);
		  Set set=sort.entrySet();
		  Iterator itr=set.iterator();*/
		  HashMapEx obj=new HashMapEx();
		  hin=obj.getValues(hash);
		  System.out.println(hin);
		  //Iterator itr=hin.iterator();
		  /*while(itr.hasNext())
		  {
			  Map.Entry m=(Map.Entry)itr.next();
			  System.out.println(m.getKey()+" "+m.getValue());
		  }*/
	}
}


