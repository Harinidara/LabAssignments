package exercise7;
import java.util.*;

public class CharacterArrayEx {
	public HashMap<Integer,Object> countCharacter(char[] car, int size)
	{
		int[] count=new int[10];
		HashMap map=new HashMap();
		for(int i=0;i<size;i++)
		{
			count[i]=1;
			for(int j=i+1;j<size;j++)
			{
				if(car[i]==car[j])
				{
					count[i]++;
					car[j]=' ';
				}
			}
			if(car[i]!=0){
			map.put(car[i],count[i]);}
		}	
		map.remove(' ');
		return map;
		
		
	}
	public static void main(String[] args)
	{
		char[] car=new char[100];
	
		Scanner sc=new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		System.out.println("enter characters");
		for(int i=0;i<size;i++)
			car[i]=sc.next().charAt(0);
		CharacterArrayEx obj=new CharacterArrayEx();
		HashMap<Integer,Object> has=new HashMap(); 
		has=obj.countCharacter(car,size);
		System.out.println(has);
				
	}
}


