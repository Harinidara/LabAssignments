package exercise7;
import java.util.*;
public class HashMap1 {
	public HashMap<Integer,String> getStudents(HashMap<Integer,Integer> hin){
			Set s=hin.entrySet();
			Iterator it=s.iterator();
			HashMap<Integer,String>hout=new HashMap<Integer,String>();
			while(it.hasNext())
			{
				Map.Entry e=(Map.Entry)it.next();
				Integer id1=(Integer)e.getKey();
				Integer marks1=(Integer)e.getValue();
				if(marks1>=90)
					hout.put(id1, "Gold");
				else if(marks1<90 && marks1>=80)
					hout.put(id1, "Silver");
				else if(marks1<80 && marks1>=70)
					hout.put(id1, "Bronze");
			}
			return hout;
		}
		public static void main(String args[]){
			HashMap<Integer,String> hout=new HashMap<Integer,String>();

			HashMap<Integer,Integer> hin=new HashMap<Integer,Integer>();
			hin.put(101,84);
			hin.put(102,75);
			hin.put(103,80);
			hin.put(104,95);
			hin.put(105,70);
			HashMap1 c=new HashMap1();
			hout=c.getStudents(hin);
			System.out.println(hout);
		}

	}

