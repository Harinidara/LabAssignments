package exercise7;
import java.util.*;
import java.util.Scanner;


public class SquareNumber {
public HashMap<Integer,Object> getSquares(int[] arr)
	{
		int s;
		int len=arr.length;
		HashMap h=new HashMap();
		for(int i=0;i<len;i++)
		{
			s=0;
			s=arr[i];
			s=s*s;
			h.put(arr[i],s);
		}
		//HashMap h=new HashMap();
		return h;
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		int[] arr=new int[size];
		System.out.println("enter numbers");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
		}
		SquareNumber  obj=new SquareNumber ();
		HashMap h=new HashMap();
		h=obj.getSquares(arr);
		System.out.println(h);
	}
}


