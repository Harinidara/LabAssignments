package exercise5.com;

class InvalidNameException extends Throwable
{
	public InvalidNameException(String errormsg)
	{
		super(errormsg);
	}
}

public class Exception3
{
	static void validation(String fname,String lname) throws InvalidNameException
	{
	if(fname.equals("")&&lname.equals(""))
		throw new InvalidNameException("Name is not validate");
	else
		System.out.println("Name is validate");

}
	public static void main(String args[]) throws InvalidNameException {
		Exception3.validation("Bhargav","Tikka");
		System.out.println("Rest of code...");
	}
}

