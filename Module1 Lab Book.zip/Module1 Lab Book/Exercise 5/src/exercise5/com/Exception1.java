package exercise5.com;
class InvalidAgeException extends Throwable
{
	public InvalidAgeException(String errormsg) {
		super(errormsg);
	}
}

public class Exception1 {
     static void validation(int age1) throws InvalidAgeException
     {
    	 if(age1<15)
    		 throw new InvalidAgeException("You are not eligible");
    	 else
    		 System.out.println("You are eligible");
     }
     public static void main(String args[]) throws InvalidAgeException
     {
    	 Exception1.validation(16);
    	 System.out.println("rest of code..");
     }
}
