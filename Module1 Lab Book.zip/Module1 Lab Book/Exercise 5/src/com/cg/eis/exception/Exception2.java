package com.cg.eis.exception;
class InvalidEmployeeException extends Throwable
{
	public InvalidEmployeeException(String errormsg) {
	super(errormsg);
}
}

public class Exception2 {
  static void validation(double salary) throws InvalidEmployeeException
  {
	  if(salary<3000)
		  throw new InvalidEmployeeException("you are not successful");
	  else
		  System.out.println("You are Successful");
  }
  public static void main(String args[]) throws InvalidEmployeeException
  {
	  Exception2.validation(4000);
	  System.out.println("Rest of code..");
  }
}
