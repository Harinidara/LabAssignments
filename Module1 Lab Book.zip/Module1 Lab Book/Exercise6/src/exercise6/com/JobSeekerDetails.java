package exercise6.com;
import java.util.Scanner;

public class JobSeekerDetails {
static boolean validateDemo(String name)
		{
			int i=0;
			String s1="_job";
			i=name.indexOf(s1);
			if(i>=8)
				 return true;	
			else
			    return false;
		}
		public static void main(String[] args) 
		{
	      Scanner sc=new Scanner(System.in);
	      System.out.println("Enter name:");
	      String s=sc.next();
	      boolean result=validateDemo(s);
	      if(result==true)
	      {
	    	  System.out.println("Valid name");
	      }
	      else
	      {
	    	  System.out.println("Invalid");
	      }
		}
}

