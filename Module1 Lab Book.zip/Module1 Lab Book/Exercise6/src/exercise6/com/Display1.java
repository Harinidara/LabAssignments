package exercise6.com;
import java.io.FileReader;
import java.io.LineNumberReader;

public class Display1 {
	public static void main(String args[]) throws Exception
		{
			FileReader f1=new FileReader("Excuseme.txt");
			LineNumberReader l1=new LineNumberReader(f1);
			String line=null;
			while((line=l1.readLine())!=null)
			{
				System.out.println(l1.getLineNumber()+" "+line);
			}
		}

	}

