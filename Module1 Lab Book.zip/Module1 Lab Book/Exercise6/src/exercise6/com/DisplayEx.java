package exercise6.com;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;


public class DisplayEx {
	public static void main(String[] args) {
			BufferedReader br=null;
			int charcount=0;
			int linecount=0;
			int wordcount=0;
			
			try {
				br=new BufferedReader(new FileReader("Hello.txt"));
				String Cline=br.readLine();
				while(Cline!=null)
				{
					linecount++;
					String words[]=Cline.split(" ");
					wordcount=wordcount+words.length;
					for(String x:words)
					{
						charcount=charcount+words.length;
					}
					Cline=br.readLine();
				}
				System.out.println("no of chars="+charcount);
				System.out.println("no of lines="+linecount);
				System.out.println("no of words="+wordcount);
			} catch (IOException e) {
				e.printStackTrace();
			}
			finally{
				try{
					br.close();
				}
				catch(IOException e){
					e.printStackTrace();
				}
			}
		}
		}


