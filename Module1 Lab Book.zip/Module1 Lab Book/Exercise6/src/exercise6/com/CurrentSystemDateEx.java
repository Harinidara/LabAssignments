package exercise6.com;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

public class CurrentSystemDateEx {
	public Period difference(){
		LocalDate ldate=LocalDate.of(1997,11,22);
		LocalDate tday=LocalDate.now();
		 Period diff= Period.between(ldate,tday);
		return diff;
	}
	public static void main(String[] args) {
		CurrentSystemDateEx  l1=new CurrentSystemDateEx ();
		Period diff=l1.difference();
		System.out.println("diff of years"+diff.getYears());
		
		System.out.println("diff of months"+diff.getMonths());
		System.out.println("diff of days"+diff.getDays());
	}
	
		
	
}

