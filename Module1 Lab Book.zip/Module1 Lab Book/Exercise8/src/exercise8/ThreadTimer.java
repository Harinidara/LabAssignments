package exercise8;
import java.util.*;
public class ThreadTimer extends TimerTask implements Runnable
{
	public void run()
	{
		System.out.println("Timer update....."+new Date());	
	}
public static void main(String args[]) throws InterruptedException
{
	TimerTask timertask=new ThreadTimer();
	Timer timer=new Timer(true);
	timer.scheduleAtFixedRate(timertask,0,10*1000);
	System.out.println("Timer update is started");
	Thread.sleep(100000);
	timer.cancel();
	System.out.println("Timer update is stopped");
}
}
