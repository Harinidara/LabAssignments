package exercise9;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FileProgram{
	//static FileInputStream f1=null;
	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		FileInputStream f1=null;
		FileOutputStream f2=null;
		try {
			f1=new FileInputStream("d:\\source.txt");
			f2=new FileOutputStream("d:\\target.txt");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CopyDataThreadEx cdt=new CopyDataThreadEx(f1,f2);
		ExecutorService ex=Executors.newFixedThreadPool(1);
		ex.execute(cdt);
	}

}
