package exercise9;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CopyDataThreadEx implements Runnable {

	FileInputStream f1;
	FileOutputStream f2;
	public CopyDataThreadEx(FileInputStream f1,FileOutputStream f2) {
		this.f1=f1;
		this.f2=f2;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			int k,c=0;
			while((k=f1.read())!=-1)
			{
				System.out.println((char)k);
				f2.write((char)k);
				c++;
				if(c==10)
				{
					System.out.println("10 characters are copied");
					Thread.sleep(500);
					c=0;
				}
			}
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		finally{
			try {
				f2.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
